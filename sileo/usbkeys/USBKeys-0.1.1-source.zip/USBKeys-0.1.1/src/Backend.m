#import "Backend.h"
#import "HID.h"
#include <IOKit/IOKitLib.h>
#include <dlfcn.h>
#include <unistd.h>

// These selectors are reverse engineered by shinyquagsire23/libusbd (MIT).
// They are verified on macOS, NOT verified on this iOS build.
typedef CFTypeRef Desc;
typedef CFTypeRef Controller;
static IOReturn (*Create)(CFAllocatorRef,Controller *);
static Desc (*Snapshot)(CFAllocatorRef,Controller);
static void (*Clear)(Desc);
static int (*AddConfig)(Desc,CFStringRef,uint8_t,uint8_t);
static int (*AddInterface)(Desc,int,CFStringRef);
static IOReturn (*Publish)(Controller,Desc);
static IOReturn (*Reenumerate)(Controller,uint32_t);
static void (*SetPID)(Desc,uint16_t);
static void (*SetClass)(Desc,uint8_t);

@implementation UKBackend {
  Controller _controller;
  Desc _saved;
  io_connect_t _port;
  uint64_t _pipe, _token;
  void *_buffer;
  BOOL _changed, _active;
  NSMutableArray<NSString *> *_events;
}
- (instancetype)init { if((self=[super init])) _events=[NSMutableArray array]; return self; }
- (BOOL)active { return _active; }
- (void)log:(NSString *)step code:(IOReturn)code {
  if(_events.count>=48) [_events removeObjectAtIndex:0];
  [_events addObject:[NSString stringWithFormat:@"%@: 0x%08x",step,code]];
}
- (NSDictionary *)result:(BOOL)ok message:(NSString *)message {
  return @{@"ok":@(ok),@"active":@(_active),@"message":message,@"diagnostics":[_events componentsJoinedByString:@"\n"],@"version":@"0.1.1 (2)"};
}
- (BOOL)loadAPI {
  const char *paths[]={"/System/Library/Frameworks/IOKit.framework/IOKit","/usr/lib/libIOUSBDevice.dylib","/System/Library/PrivateFrameworks/IOUSBDeviceFamily.framework/IOUSBDeviceFamily"};
  for(unsigned i=0;i<3;i++) dlopen(paths[i],RTLD_NOW|RTLD_GLOBAL);
#define LOAD(var,name) do { *(void **)(&var)=dlsym(RTLD_DEFAULT,name); if(!var) { [_events addObject:@"Missing symbol: " @name]; return NO; } } while(0)
  LOAD(Create,"IOUSBDeviceControllerCreate");
  LOAD(Snapshot,"IOUSBDeviceDescriptionCreateFromController");
  LOAD(Clear,"IOUSBDeviceDescriptionRemoveAllConfigurations");
  LOAD(AddConfig,"IOUSBDeviceDescriptionAppendConfiguration");
  LOAD(AddInterface,"IOUSBDeviceDescriptionAppendInterfaceToConfiguration");
  LOAD(Publish,"IOUSBDeviceControllerSetDescription");
  LOAD(Reenumerate,"IOUSBDeviceControllerGoOffAndOnBus");
  LOAD(SetPID,"IOUSBDeviceDescriptionSetProductID");
  LOAD(SetClass,"IOUSBDeviceDescriptionSetClass");
#undef LOAD
  return YES;
}
- (NSDictionary *)probe {
  if(_active) return [self result:YES message:@"USB keyboard configured. Use a harmless text field to test."];
  [_events removeAllObjects];
  if(![self loadAPI]) return [self result:NO message:@"USB device API unavailable. No USB settings changed."];
  Controller c=NULL; IOReturn r=Create(NULL,&c); [self log:@"Create controller" code:r];
  if(r||!c) return [self result:NO message:@"Cannot access device-mode controller. No USB settings changed."];
  Desc d=Snapshot(NULL,c);
  if(d) CFRelease(d); CFRelease(c);
  return [self result:d!=NULL message:d?@"Controller and snapshot API found. Keyboard support still unverified.":@"Could not capture USB configuration. Start is blocked."];
}
- (IOReturn)scalar:(uint32_t)selector args:(const uint64_t *)args count:(uint32_t)count {
  return IOConnectCallScalarMethod(_port,selector,args,count,NULL,NULL);
}
- (void)closePort {
  if(_port) {
    if(_token) { uint64_t a[]={_token}; [self scalar:19 args:a count:1]; }
    [self scalar:1 args:NULL count:0]; IOServiceClose(_port);
  }
  _port=0; _token=0; _buffer=NULL; _pipe=0; _active=NO;
}
- (NSDictionary *)stop {
  [self closePort];
  if(_changed&&_saved&&_controller) {
    IOReturn r=Publish(_controller,_saved); [self log:@"Restore original USB description" code:r];
    if(r) return [self result:NO message:@"Restore failed. Unplug cable and reboot the 13 Pro Max to restore its stock USB stack."];
    r=Reenumerate(_controller,250); [self log:@"Restore re-enumeration" code:r];
    if(r) return [self result:NO message:@"Original description restored, but reconnect failed. Unplug and reconnect the cable."];
    _changed=NO;
  }
  if(_saved) { CFRelease(_saved); _saved=NULL; }
  if(_controller) { CFRelease(_controller); _controller=NULL; }
  return [self result:YES message:@"Stopped. Original USB description restored when needed."];
}
- (NSDictionary *)failed:(NSString *)why {
  NSDictionary *cleanup=[self stop];
  return [self result:NO message:[NSString stringWithFormat:@"%@ %@",why,cleanup[@"message"]]];
}
- (NSDictionary *)start {
  if(_active) return [self result:YES message:@"Already configured."];
  if(_changed) return [self result:NO message:@"Restore the previous session using Stop first."];
  [_events removeAllObjects];
  if(![self loadAPI]) return [self result:NO message:@"Required USB symbols missing. No changes made."];
  IOReturn r=Create(NULL,&_controller); [self log:@"Create controller" code:r];
  if(r||!_controller) return [self failed:@"Controller access failed."];
  _saved=Snapshot(NULL,_controller);
  Desc edited=Snapshot(NULL,_controller);
  if(!_saved||!edited) { if(edited) CFRelease(edited); return [self failed:@"USB snapshot failed. No configuration published."]; }
  Clear(edited); SetClass(edited,0); SetPID(edited,0x1337);
  int cfg=AddConfig(edited,CFSTR("USBKeys experimental keyboard"),0x80,50);
  if(cfg<0||AddInterface(edited,cfg,CFSTR("USBKeysKeyboard"))<0) { CFRelease(edited); return [self failed:@"Cannot describe keyboard interface."]; }
  // Mark before call: even a failing private call could have changed state.
  _changed=YES; r=Publish(_controller,edited); CFRelease(edited);
  [self log:@"Publish keyboard description" code:r];
  if(r) return [self failed:@"USB publication rejected. An entitlement or driver restriction may block this port."];
  io_service_t service=0;
  for(int attempt=0;attempt<30&&!service;attempt++) {
    NSMutableDictionary *m=[@{@"IOProviderClass":@"IOUSBDeviceInterface",@"IOPropertyMatch":@{@"USBDeviceFunction":@"USBKeysKeyboard"}} mutableCopy];
    service=IOServiceGetMatchingService(0,(__bridge_retained CFDictionaryRef)m);
    if(!service) usleep(100000);
  }
  if(!service) return [self failed:@"Kernel did not create a userspace USB interface."];
  r=IOServiceOpen(service,mach_task_self(),123,&_port); IOObjectRelease(service);
  [self log:@"Open interface user client type 123" code:r];
  if(r) return [self failed:@"USB interface user client unavailable on this build."];
  uint64_t open[]={0};
  r=[self scalar:0 args:open count:1]; [self log:@"Open interface" code:r];
  if(r) return [self failed:@"Interface open rejected."];
  for(unsigned sel=3;sel<=5;sel++) {
    uint64_t a[]={sel==3?3:1,(uint64_t)cfg};
    r=[self scalar:sel args:a count:2]; [self log:[NSString stringWithFormat:@"Set interface field %u",sel] code:r];
    if(r) return [self failed:@"HID interface setup rejected."];
  }
  const uint16_t length=sizeof(UKReportDescriptor);
  const uint8_t hid[]={9,0x21,0x11,0x01,0,1,0x22,length&255,length>>8};
  uint64_t descriptorArgs[]={0x21,0xf};
  r=IOConnectCallMethod(_port,6,descriptorArgs,2,hid,sizeof(hid),NULL,NULL,NULL,NULL);
  [self log:@"Install HID descriptor" code:r]; if(r) return [self failed:@"HID descriptor rejected."];
  descriptorArgs[0]=0x22;
  r=IOConnectCallMethod(_port,7,descriptorArgs,2,UKReportDescriptor,sizeof(UKReportDescriptor),NULL,NULL,NULL,NULL);
  [self log:@"Install report descriptor" code:r]; if(r) return [self failed:@"Report descriptor rejected."];
  uint64_t pipeArgs[]={3,1,8,10,0,(uint64_t)cfg}; uint32_t n=1;
  r=IOConnectCallScalarMethod(_port,10,pipeArgs,6,&_pipe,&n);
  [self log:@"Create interrupt IN endpoint" code:r]; if(r||n!=1) return [self failed:@"Endpoint creation failed."];
  uint64_t size[]={4096}, out[3]={0}; n=3;
  r=IOConnectCallScalarMethod(_port,18,size,1,out,&n);
  [self log:@"Map report buffer" code:r];
  if(r||n!=3||!out[0]||out[1]<8||!out[2]) return [self failed:@"Report buffer mapping failed."];
  _buffer=(void *)(uintptr_t)out[0]; _token=out[2];
  r=[self scalar:11 args:NULL count:0]; [self log:@"Commit interface" code:r];
  if(r) return [self failed:@"Interface commit rejected."];
  r=Reenumerate(_controller,250); [self log:@"Re-enumerate as keyboard" code:r];
  if(r) return [self failed:@"Re-enumeration failed."];
  _active=YES;
  return [self result:YES message:@"Keyboard configured locally. Host recognition is unverified. Test one key in a harmless text field."];
}
- (IOReturn)report:(const uint8_t *)bytes {
  memcpy(_buffer,bytes,8); uint64_t a[]={_pipe,_token,8,250}, written=0; uint32_t n=1;
  IOReturn r=IOConnectCallScalarMethod(_port,14,a,4,&written,&n);
  return !r&&(n!=1||written!=8)?kIOReturnUnderrun:r;
}
- (NSDictionary *)key:(uint8_t)key modifier:(uint8_t)modifier {
  if(!_active) return [self result:NO message:@"Press Start before sending keys."];
  if(key<4||key>0x65) return [self result:NO message:@"Unsupported HID usage."];
  uint8_t press[8]={modifier,0,key,0,0,0,0,0}, release[8]={0};
  IOReturn r=[self report:press]; usleep(20000); IOReturn up=[self report:release];
  // Never log key values, typed text, or passcodes.
  if(r||up) { [self log:@"Key transport" code:r?r:up]; return [self failed:@"Host did not acknowledge both key press and release. Session stopped; no automatic retry."]; }
  return [self result:YES message:@"Key reports transferred. This does not prove the host accepted the input."];
}
@end

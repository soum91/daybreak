# Changelog

## 0.1.1-1 (packaging revision)

- Rebuild only; app and daemon binaries and app metadata are byte-for-byte identical to 0.1.1 (2). The user's screenshot confirms the UI now launches, but installation failed because the maintainer script called nonexistent `/bin/launchctl`.
- Resolve launchctl from an explicit rootless Procursus PATH in install/remove scripts; declare launchctl and uikittools dependencies.
- Create the runtime socket directory with root/mobile permissions before service loading. Replace a stale socket, attempt bootstrap with load fallback, and check that the control socket appears before reporting installation success.
- Added seven installer tests using mocked launchctl/uicache/chown and socket-type filesystem fixtures. They cover both rootless executable locations, bootstrap fallback, startup failure, missing command, missing socket, and removal. Actual launchd service startup and USB HID operation still require physical verification.

## 0.1.1 (2)

- Fixed a verified binary corruption in 0.1.0: the signature load command overwrote the first 16 bytes of executable code in both app and daemon.
- Rebuilt with the standard iOS clang/ld64 toolchain and explicit header padding. Added mandatory before/after signing checks for all __TEXT sections and load-command boundaries. Both old binaries fail this check; both rebuilt binaries pass.
- Removed the unnecessary app IOKit dependency and automatic USB probe on app launch.
- Added explicit container entitlements and complete platform bundle metadata.
- Read the app version/build from installed Info.plist. Added clipboard read-back verification and native Save report.
- Cross-compiled and checked package/signatures/ASCII mappings. Physical launch, export UI, and USB HID operation remain unverified.

## 0.1.0 (1)

- Added experimental Lightning USB HID keyboard publication via IOKit.
- Added rootless Home Screen app and privileged service with restricted local IPC.
- Added numeric keypad, US ASCII typing, navigation keys, and explicit Start/Stop.
- Added snapshot restoration, inactivity timeout, and transport error handling.
- Added installed version, copy/share diagnostics, and generated app icon.
- Cross-compiled and signed arm64 binaries; tested ASCII mapping and descriptor
  boundaries. Hardware operation and Recovery Assistant support remain untested.

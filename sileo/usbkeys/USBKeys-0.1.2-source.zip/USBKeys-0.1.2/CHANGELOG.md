# Changelog

## 0.1.2 (3): complete operation diagnostics

- Fixed a confirmed reporting gap: successful controller creation was logged, but USB snapshot calls and their NULL results were not. Check USB and Start could therefore show the same one-line log.
- Record operation, API stage, snapshot result, service version/PID, activity state, and final status together in the on-screen and exported report. Show specific IPC stage/errno rather than leaving an old success line visible.
- Persist diagnostic-only step state before private USB calls. Add Last result, which reads it independently of the socket; preserve the last interrupted session through service restart. No typed text or key values are recorded.
- Capture read-only controller class and relevant registry property names/types, without property values or device identifiers. Reject aliased snapshot objects before editing a working description.
- Disable keys until live setup succeeds; a saved report cannot activate them. Catch service Objective-C exceptions and disable keys on failure. After an interrupted publication, refuse another setup in the same boot because the prior in-memory restoration snapshot is lost.
- Retain the corrected rootless installer and signing checks. Build/package checks, seven mocked installer tests, and HID mapping tests pass. This is a diagnostics and error-handling update; snapshot failure, physical journal/export access, and USB keyboard operation are not device-verified.

## 0.1.1-1 (packaging revision)

- Rebuild only; app and daemon binaries and app metadata are byte-for-byte identical to 0.1.1 (2). The user's screenshot confirms the UI now launches, but installation failed because the maintainer script called nonexistent `/bin/launchctl`.
- Resolve launchctl from an explicit rootless Procursus PATH in install/remove scripts; declare launchctl and uikittools dependencies.
- Create the runtime socket directory with root/mobile permissions before service loading. Replace a stale socket, attempt bootstrap with load fallback, and check that the control socket appears before reporting installation success.
- Added seven installer tests using mocked launchctl/uicache/chown and socket-type filesystem fixtures. They cover both rootless executable locations, bootstrap fallback, startup failure, missing command, missing socket, and removal. Actual launchd service startup and USB HID operation still require physical verification.

## 0.1.1 (2)

- Fixed a verified binary corruption in 0.1.0: the signature load command overwrote the first 16 bytes of executable code in both app and daemon.
- Rebuilt with the standard iOS clang/ld64 toolchain and explicit header padding. Added mandatory before/after signing checks for all __TEXT sections and load-command boundaries. Both old binaries fail this check; both rebuilt binaries pass.
- Removed the unnecessary app IOKit dependency and automatic USB probe on app launch.
- Added explicit container entitlements and complete platform bundle metadata.
- Read the app version/build from installed Info.plist. Added clipboard read-back verification and native Save report.
- Cross-compiled and checked package/signatures/ASCII mappings. Physical launch, export UI, and USB HID operation remain unverified.

## 0.1.0 (1)

- Added experimental Lightning USB HID keyboard publication via IOKit.
- Added rootless Home Screen app and privileged service with restricted local IPC.
- Added numeric keypad, US ASCII typing, navigation keys, and explicit Start/Stop.
- Added snapshot restoration, inactivity timeout, and transport error handling.
- Added installed version, copy/share diagnostics, and generated app icon.
- Cross-compiled and signed arm64 binaries; tested ASCII mapping and descriptor
  boundaries. Hardware operation and Recovery Assistant support remain untested.

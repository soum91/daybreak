#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SDKROOT:?Set SDKROOT to an iPhoneOS SDK}"
: "${ZIG:?Set ZIG to the Zig 0.14.1 executable}"
: "${LDID:?Set LDID to ldid}"
mkdir -p build dist
stage="$PWD/build/stage"
rm -rf "$stage"
mkdir -p "$stage/DEBIAN" "$stage/var/jb/Applications/USBKeys.app" "$stage/var/jb/usr/libexec" "$stage/var/jb/Library/LaunchDaemons"
app="$stage/var/jb/Applications/USBKeys.app"
flags=(-target aarch64-ios.16.1 -isysroot "$SDKROOT" -isystem "$SDKROOT/usr/include" -F"$SDKROOT/System/Library/Frameworks" -L"$SDKROOT/usr/lib" -fobjc-arc -fblocks -Os -Wall -Wno-nullability-completeness -Wno-macro-redefined -Wno-unknown-warning-option)
"$ZIG" cc "${flags[@]}" -framework UIKit -framework Foundation -framework CoreFoundation -framework IOKit src/App.m -o "$app/USBKeys"
"$ZIG" cc "${flags[@]}" -framework Foundation -framework CoreFoundation -framework IOKit src/Daemon.m src/Backend.m -o "$stage/var/jb/usr/libexec/usbkeysd"
"$LDID" -Spackaging/app-entitlements.plist "$app/USBKeys"
"$LDID" -Spackaging/entitlements.plist "$stage/var/jb/usr/libexec/usbkeysd"
python3 scripts/package_metadata.py "$stage"
cp packaging/control packaging/postinst packaging/prerm packaging/postrm "$stage/DEBIAN/"
chmod 0755 "$stage/DEBIAN/"{postinst,prerm,postrm} "$app/USBKeys" "$stage/var/jb/usr/libexec/usbkeysd"
dpkg-deb --root-owner-group -Zxz --build "$stage" dist/dev.usbkeys.keyboard_0.1.0_iphoneos-arm64.deb

# Changelog

## 0.1.0 (1)

- Added experimental Lightning USB HID keyboard publication via IOKit.
- Added rootless Home Screen app and privileged service with restricted local IPC.
- Added numeric keypad, US ASCII typing, navigation keys, and explicit Start/Stop.
- Added snapshot restoration, inactivity timeout, and transport error handling.
- Added installed version, copy/share diagnostics, and generated app icon.
- Cross-compiled and signed arm64 binaries; tested ASCII mapping and descriptor
  boundaries. Hardware operation and Recovery Assistant support remain untested.

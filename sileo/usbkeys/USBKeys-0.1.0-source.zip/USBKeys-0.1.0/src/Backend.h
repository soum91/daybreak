#import <Foundation/Foundation.h>
@interface UKBackend : NSObject
@property(nonatomic,readonly) BOOL active;
- (NSDictionary *)probe;
- (NSDictionary *)start;
- (NSDictionary *)stop;
- (NSDictionary *)key:(uint8_t)key modifier:(uint8_t)modifier;
@end

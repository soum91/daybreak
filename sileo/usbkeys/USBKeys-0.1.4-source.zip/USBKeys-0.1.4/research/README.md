# iOS 16.1.1 USB interface investigation

The user's 0.1.2 screenshot fails at IOServiceOpen(type 123), after descriptions
were captured and the USB interface was published. That screenshot alone omits
the return code, so it does not establish permission denial versus another error.
The old failure message incorrectly called every error an unavailable user client.

The Apple-supplied iPhone14,3 / 20B101 kernel was extracted read-only from the IPSW
in `20B101-usb-evidence.json`. Its IOUSBDeviceFamily contains the real
IOUSBDeviceInterfaceUserClient implementation. Its dispatcher argument counts
match the selectors used here, as checked by `tests/usb_abi_test.py` against the
actual extracted kext. This rules out simply saying the class is absent. It does
not prove access or hardware behavior. The kernel and kext are not redistributed.

The prior helper incorrectly declared `com.apple.private.iokit-user-client-class`.
The corrected helper declares `com.apple.security.exception.iokit-user-client-class`
with only IOUSBDeviceInterfaceUserClient, matching the class exception used by
Apple's dmd service in the nearby 16.1.2 / 20B110 entitlement dump:
https://github.com/ChiChou/entdb-data/blob/main/iOS/16.1.2_20B110/bin/usr/libexec/dmd.xml
It also declares the USB device-access boolean documented by Apple:
https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.security.device.usb
A signed-binary check confirms both keys exist in the packaged helper. Runtime
permission reads and the exact IOServiceOpen error are included in 0.1.3 reports.

This is a concrete entitlement correction and more accurate error reporting,
not proof that it resolves the user's IOServiceOpen failure. The class exists;
the access failure's specific return code and the effect of the fix still need
on-device verification. No user-client type scanning or kernel patch was added.
